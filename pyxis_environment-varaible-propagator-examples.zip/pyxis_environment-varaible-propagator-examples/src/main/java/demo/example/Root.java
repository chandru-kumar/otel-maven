package demo.example;

import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;

import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapSetter;

public class Root {
	
	public static final String TRACEBAGGAGEVALUE = "cs.span.parent.id= 825553,cs.span.hash= a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad,"
			+ "cs.trace.id=a1308136f4fbc328358fa6237468ada5581,cs.trace.name=test_trace,cs.trace.time.start=1554843980180184094,"
			+ "cs.span.id=fa6237468ada558,cs.span.name=test_span_name,cs.span.time.start=1554843980180184094,"
			+ "cs.span.links=http://testlink/spanlink,cs.span.retry.id=1,cs.span.service.type=test,cs.span.service.name=spanservicename,"
			+ "cs.span.version= 1.0,cs.span.op.name= game_gccgm_game_card_cust_guid_map,cs.span.op.type=CREATETABLE,"
			+ "cs.trace.name=AUTO_DBT_TC_190,cs.trace.parent.id=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type=EE,cs.trace.version=1.0";
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("ROOT");
	  public static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);
	  
	  public static final TextMapSetter<Map<String, String>> setter = Map::put;
	
	

	public static void main(String[] args) {
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder("GMS_MERCHANT_HIER_INSIGHTS -" + hostname).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "GMS_MERCHANT_HIER_INSIGHTS");
			//DataIngestionPreProcessingModuleExample.process();
			
			ProcessBuilder processBuilder = new ProcessBuilder();
			Map<String, String> env = processBuilder.environment();
			
			EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), env, setter);
			
			System.out.println(Context.current());
			
			Span Test =  tracer.spanBuilder("Test").startSpan();
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Test.end();
			
			Span Test1 =  tracer.spanBuilder("Test-1").startSpan();
			Test1.makeCurrent();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), env, setter);
			Test1.end();
			
			Span Test2 =  tracer.spanBuilder("Test-2").startSpan();
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Test2.end();
			
			Span Test3 =  tracer.spanBuilder("Test-3").startSpan();
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			Test3.end();
			
			try {
				//processBuilder.command("sh", "java -cp /adshome/crkuma/GMS-Demo.jar demo.example.SOR");
				processBuilder.command("sh", "-c", "java -cp /adshome/crkuma/GMS-Demo.jar demo.example.SOR");
				//processBuilder.command("java -cp /adshome/crkuma/GMS-Example.jar demo.example.SOR");
				processBuilder.start();
				

			} catch (Exception e) {
				System.out.println("Error calling DataIngestionPreProcessingModuleExample.jar "+e);
			}
			
			
			

		} finally {
			span.end();
		}

	}

}
