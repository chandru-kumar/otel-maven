package demo.example;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

public class Hive {

	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};
	
	static Map<String, String> env = System.getenv();

	/*static Context context = CompositeEnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance(),
			SSHW3CBaggagePropagator.getInstance()).extract(Context.current(), env, getter);*/
	
	static Context context = EnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("Hive");
	private static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);

	
	static Predicate<Tracer> executeTasks = (tracer) -> {

		Instant start = Instant.now();
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder("Preventive Rule.hql - " +hostname ).setParent(context).startSpan();
				//.setSpanKind(SpanKind.CONSUMER).startSpan();
		
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "Hive");
			span.setAttribute("propagator", "SSH");


			/*Map<String, BaggageEntry> baggageMap = Baggage.fromContext(context).asMap();

			for (Map.Entry<String, BaggageEntry> entry : baggageMap.entrySet()) {
				span.setAttribute(entry.getKey(),
						entry.getValue().getValue().concat(entry.getValue().getMetadata().getValue()));
			}*/
			
			Span ddlTask = tracer.spanBuilder("DDL Task").startSpan();
			//call task
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ddlTask.end();
			
			Span mapReduceTask = tracer.spanBuilder("MapReduce Task").startSpan();
			//call task
			try {
				Thread.sleep(600);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			mapReduceTask.end();
			
			Span statsTask = tracer.spanBuilder("Stats Task").startSpan();
			//call task
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			statsTask.end();
			
			Span moveTask = tracer.spanBuilder("Move Task").startSpan();
			//call task
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			moveTask.end();
			
			ProcessBuilder processBuilder1 = new ProcessBuilder("sh", "-c", "ssh crkuma@lppbd3034 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.Cloak");
			//ProcessBuilder processBuilder1 = new ProcessBuilder("sh", "ssh crkuma@lppbd3034 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.Cloak");
			/*Map<String, String> envVar = processBuilder.environment();
			envVar.put("XMODIFIERS", "00-".concat(span.getSpanContext().getTraceId()).
					concat("-").
					concat(span.getSpanContext().getSpanId()).
					concat("-").
					concat(String.valueOf(span.getSpanContext().isSampled())));*/
			//EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), envVar, Root.setter);
			try {
				processBuilder1.start();

			} catch (Exception e) {
				
			}

		} 
		
		catch(Exception e) {
			return false;
		}
		
		finally {
			span.end();
			Instant finish = Instant.now();
			long timeElapsed = Duration.between(start, finish).toMillis();
			System.out.println("Extracted trace details, created Spans and Baggages..in" + timeElapsed + " ms");
		}
		
		return true;
	};
	
	public static void main(String[] args) {
		
		/*captureHostname.get();
		preventRule.get();*/
		executeTasks.test(tracer);
		
		
		
		/*CompletableFuture<Boolean> completableFuture1 = CompletableFuture.supplyAsync(() -> initializeOpenTelemetryFeature.get())
				 .thenApplyAsync(openTelemtry -> getTracer.apply(openTelemtry))
				 .thenApplyAsync(tracer -> createTraceSpansAndExtract.test(tracer))
				 .thenApplyAsync(flag -> {
					return flag; 
				 });*/
		


		/*try {
			completableFuture1.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

}
