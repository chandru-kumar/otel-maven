package demo.example;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import com.amex.otel.environment.variable.propagator.baggage.validator.BaggageValidator;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

public class Cloak extends BaggageValidator {
	
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};
	
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("Cloak");
	private static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);
	
	static Map<String, String> env = System.getenv();
	
	/*static Context context = CompositeEnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance(), SSHW3CBaggagePropagator.getInstance()).extract(Context.current(), env, getter);*/
	
	static Context context = EnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);


	public Cloak() {
	}
	
	static Predicate<Tracer> hiveLoad = (tracerObj) -> {
		
		Span span = tracer.spanBuilder("HIve load: 500 Internal server error").setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "cloak service");
			span.setAttribute("propagator", "composite");
			
			//ProcessBuilder processBuilder = new ProcessBuilder("CMD", "/C", "SET");
			// ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", "java -jar
			// /adshome/crkuma/JAVA2JAVAB3PropagatorExtractor.jar");
			//ProcessBuilder processBuilder = new ProcessBuilder("java","-jar","/adshome/crkuma/CompositeEnvVarPropagatorExtractor.jar");
			//ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", "ssh crkuma@lppbd0040 java -jar /adshome/crkuma/HiveTaskExample-DISTTACE.jar");
			//ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", "ssh qryprfs@lppbd0040 /axp/rim/qryprf/dev/observability/sql/hive_example.sh");
			//ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar", "P:\\HiveTaskExample.jar");


			/*try {
				processBuilder.start();

			} catch (Exception e) {
				
				return false;
			}*/
			
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			span.setStatus(StatusCode.ERROR, "500 Internal Error");

		} finally {
			
			span.end();
			
			System.out.println("Span ended in finally...");
		}
		return true;

	
	};

	private static Supplier<String> encryption = () -> {
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder("Encrption" +hostname).setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "Cloak service");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		} finally {
			span.end();
		}
		
		return "dataIngestion";
	};

	/*private static Supplier<String> platformDataStandardizer = () -> {
		
		Span span = tracer.spanBuilder("Platform Data Standardizer").setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "Platform Data Standardizer");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		} finally {
			span.end();
		}
		return "platformDataStandardizer";
	};
	*/
	
	public static void process() {
		
		
		encryption.get();
		//platformDataStandardizer.get();
		hiveLoad.test(tracer);

		/*CompletableFuture<Boolean> completableFuture1 = CompletableFuture.supplyAsync(() -> initializeOpenTelemetryFeature.get())
				 .thenApplyAsync(openTelemtry -> getTracer.apply(openTelemtry))
				 .thenApplyAsync(tracer -> calHiveTasks.test(tracer))
				 .thenApplyAsync(flag -> {
					return flag; 
				 });*/
		
		//System.out.println(callHiveTasks.test(Scheduler.tracer));

		/*try {
			completableFuture1.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	
	}

	public static void main(String[] args) {
		
		process();

	}

}
