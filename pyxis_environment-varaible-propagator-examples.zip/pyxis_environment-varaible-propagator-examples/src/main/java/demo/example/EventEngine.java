package demo.example;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import org.apache.logging.log4j.LogManager;

import com.amex.otel.environment.variable.propagator.baggage.validator.BaggageValidator;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

public class EventEngine extends BaggageValidator {
	
	private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(EventEngine.class.getName());
	
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};
	
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("Event Engine");
	private static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);
	
	static Map<String, String> env = System.getenv();
	
	/*static Context context = CompositeEnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance(), SSHW3CBaggagePropagator.getInstance()).extract(Context.current(), env, getter);*/
	
	static Context context = EnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);


	public EventEngine() {
	}

	private static Supplier<String> sftpEventTriggered = () -> {
		
		System.out.println("Calling Event Engine");
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}
		
		Span span = tracer.spanBuilder("sftp event triggered -" +hostname).setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		
		try (Scope scope = span.makeCurrent()) {

		/*Span span = tracer.spanBuilder("sftp event triggered -" +hostname).setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();*/
		
		span.setAttribute("component", "SFTP");
		
		
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		ProcessBuilder processBuilder = new ProcessBuilder();
		
		log.info("Event Engine ======>>>>Injecting context :::"+Context.current());
		System.out.println("Event Engine ======>>>>Injecting context :::"+Context.current());
		//EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), envVar, Root.setter);

		try {
			//processBuilder.command("sh", "ssh crkuma@lppbd0040 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.DataIngestion");
			processBuilder.command("sh", "-c", "ssh crkuma@lppbd0040 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.DataIngestion");
			//processBuilder.command("ssh crkuma@lppbd0040 java -cp /adshome/crkuma/GMS-Example.jar demo.example.DataIngestion");
			processBuilder.start();

		} catch (Exception e) {
			
		}
		
		
		span.end();
		}
		
		return "dataIngestion";
	};

	
	public static void process() {
		
		log.info("Event Engine ======>>>>Starts");
		sftpEventTriggered.get();
		log.info("Event Engine ======>>>>ends");
	
	}

	public static void main(String[] args) {
		
		process();

	}

}
