/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

package demo.example;

import java.time.Duration;
import java.time.Instant;
import java.util.function.Function;

import org.apache.logging.log4j.LogManager;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.exporter.zipkin.ZipkinSpanExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;

/**
 * All SDK management takes place here, away from the instrumentation code, which should only access
 * the OpenTelemetry APIs.
 */
public class TelemetryManager {
  // Zipkin API Endpoints for uploading spans
  private static final String ENDPOINT_V2_SPANS = "/api/v2/spans";
  
  private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(TelemetryManager.class.getName());
  
  static Function<String, OpenTelemetry> initializeOpenTelemetryFeature = (servicename) -> {
		log.info("Initializing OpenTelemetry.."+servicename);
		return TelemetryManager.initializeOpenTelemetry("10.16.126.64", 9411, servicename);
	};

	static Function<OpenTelemetry, Tracer> getTracer = (openTelemetry) -> {
		Instant start = Instant.now();
		Tracer tracer;
		TracerProvider tracerProvider = openTelemetry.getTracerProvider();
		tracer = tracerProvider.get("environment.varaible.propagator.examples.CompositeEnvVarPropagatorInjector");
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();
		log.info("Returning Tracer..in" + timeElapsed + " ms");
		return tracer;
	};
  
  static OpenTelemetry initializeOpenTelemetry(String ip, int port, String SERVICE_NAME) {
	  Instant start = Instant.now();
	    String httpUrl = String.format("http://%s:%s", ip, port);
	    ZipkinSpanExporter zipkinExporter =
	        ZipkinSpanExporter.builder().setEndpoint(httpUrl + ENDPOINT_V2_SPANS).build();

	    Resource serviceNameResource =
	        Resource.create(Attributes.of(AttributeKey.stringKey("service.name"), SERVICE_NAME));
	    
	    // Set to process the spans by the Zipkin Exporter
	    SdkTracerProvider tracerProvider =
	        SdkTracerProvider.builder()
	            .addSpanProcessor(SimpleSpanProcessor.create(zipkinExporter))
	            .setResource(Resource.getDefault().merge(serviceNameResource))
	            .build();
	    OpenTelemetrySdk openTelemetry =
	        OpenTelemetrySdk.builder().setTracerProvider(tracerProvider).buildAndRegisterGlobal();

	    // add a shutdown hook to shut down the SDK
	    Runtime.getRuntime().addShutdownHook(new Thread(tracerProvider::shutdown));
	    
	    Instant finish = Instant.now();
	    long timeElapsed = Duration.between(start, finish).toMillis();
	    // return the configured instance so it can be used for instrumentation.
	    log.info("Initialized OpenTelemetry in " + timeElapsed + "ms");
	    return openTelemetry;
	  }
}
