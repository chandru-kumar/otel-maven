package demo.example;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import org.apache.logging.log4j.LogManager;

import com.amex.otel.environment.variable.propagator.baggage.validator.BaggageValidator;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

public class DataIngestion extends BaggageValidator {
	
	private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(DataIngestion.class.getName());
	
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};
	
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("Data Ingestion");
	private static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);
	
	static Map<String, String> env = System.getenv();
	
	/*static Context context = CompositeEnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance(), SSHW3CBaggagePropagator.getInstance()).extract(Context.current(), env, getter);*/
	
	static Context context = EnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);


	public DataIngestion() {
	}

	private static Supplier<String> dataIngestionProcess = () -> {
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}
		
		Span span = tracer.spanBuilder("GMS_MERCHANT_HIER_INSIGHTS - " +hostname)
				.setParent(context)
				.setSpanKind(SpanKind.CLIENT)
				.startSpan();
		
		try (Scope scope = span.makeCurrent()) {
			
			
			span.setAttribute("component", "triggerParser");
			Span TriggerParser =  tracer.spanBuilder("Trigger Parser").startSpan();
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			TriggerParser.end();
			
			Span platformDataStandardizer =  tracer.spanBuilder("Platform Data Standardizer").startSpan();
			
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			ProcessBuilder processBuilder = new ProcessBuilder();
			//Map<String, String> envVar = processBuilder.environment();
			
			System.out.println("DataIngestion ======>>>>Injecting context :::"+Context.current());
			log.info("DataIngestion ======>>>>Injecting context :::"+Context.current());
			//EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), envVar, Root.setter);
			try {
				//processBuilder.command("sh", "ssh crkuma@lppbd3134 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.DQM");
				processBuilder.command("sh", "-c", "ssh crkuma@lppbd3134 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.DQM");
				//processBuilder.command("ssh crkuma@lppbd3134 java -cp /adshome/crkuma/GMS-Example.jar demo.example.DQM");
				processBuilder.start();

			} catch (Exception e) {
				
			}
			platformDataStandardizer.end();
			
			

			
			
			Span masking =  tracer.spanBuilder("masking").startSpan();
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			masking.end();
			
			
			Span dataWriter =  tracer.spanBuilder("data writer").startSpan();
			
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			dataWriter.end();
			span.end();
		} 
		
		return "dataIngestion";
	};

	
	public static void process() {
		
		
		dataIngestionProcess.get();
		/*platformDataStandardizer.get();
		processDataAndCallHiveTasks.test(tracer);
		masking.get();
		dataWriter.get();*/
	
	}

	public static void main(String[] args) {
		
		process();

	}

}
