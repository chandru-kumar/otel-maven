package demo.example;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import org.apache.logging.log4j.LogManager;

import com.amex.otel.environment.variable.propagator.baggage.validator.BaggageValidator;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

public class SOR extends BaggageValidator {
	
	private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(SOR.class.getName());
	
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};
	
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("SOR");
	private static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);
	
	static Map<String, String> env = System.getenv();
	
	/*static Context context = CompositeEnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance(), SSHW3CBaggagePropagator.getInstance()).extract(Context.current(), env, getter);*/
	
	static Context context = EnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);


	public SOR() {
	}

	private static Supplier<String> pushFileToSFTP = () -> {
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder("push file to sftp").setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		
		try (Scope scope = span.makeCurrent()) {
		
		span.setAttribute("component", "SOR");
		
		
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		ProcessBuilder processBuilder = new ProcessBuilder();
		//Map<String, String> envVar = processBuilder.environment();
		log.info("SOR ======>>>>Injecting context :::"+Context.current());
		System.out.println("SOR======>>>>Injecting context :::"+Context.current());
		//EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), envVar, Root.setter);


		try {
			//processBuilder.command("sh", "java -cp /adshome/crkuma/GMS-Demo.jar demo.example.SFTP");
			processBuilder.command("sh", "-c", "java -cp /adshome/crkuma/GMS-Demo.jar demo.example.SFTP");
			//processBuilder.command("java -cp /adshome/crkuma/GMS-Example.jar demo.example.SFTP");
			processBuilder.start();

		} catch (Exception e) {
			
		}
		
		
		span.end();
		}
		
		return "dataIngestion";
	};

	
	public static void process() {
		
		
		pushFileToSFTP.get();
	
	}

	public static void main(String[] args) {
		
		process();

	}

}
