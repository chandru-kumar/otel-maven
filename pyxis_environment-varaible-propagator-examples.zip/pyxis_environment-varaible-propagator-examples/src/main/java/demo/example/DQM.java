package demo.example;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.function.Supplier;

import javax.annotation.Nullable;

import org.apache.logging.log4j.LogManager;

import com.amex.otel.environment.variable.propagator.baggage.validator.BaggageValidator;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;

public class DQM extends BaggageValidator {
	
	private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(DQM.class.getName());
	
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};
	
	
	private static OpenTelemetry openTelemetry = TelemetryManager.initializeOpenTelemetryFeature.apply("DQM");
	private static Tracer tracer = TelemetryManager.getTracer.apply(openTelemetry);
	
	static Map<String, String> env = System.getenv();
	
	/*static Context context = CompositeEnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance(), SSHW3CBaggagePropagator.getInstance()).extract(Context.current(), env, getter);*/
	
	static Context context = EnvironmentVariablePropagator.getInstance(
			SSHW3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);


	public DQM() {
	}

	private static Supplier<String> totalCount = () -> {
		
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder("totalcount -" +hostname).setParent(context).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		
		try (Scope scope = span.makeCurrent()) {
		
		span.setAttribute("component", "DQM");
		
		
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		ProcessBuilder processBuilder = new ProcessBuilder();
		//Map<String, String> envVar = processBuilder.environment();
		log.info("DQM ======>>>>Injecting context :::"+Context.current());
		System.out.println("DQM ======>>>>Injecting context :::"+Context.current());
		//EnvironmentVariablePropagator.getInstance(SSHW3CTraceContextPropagator.getInstance()).inject(Context.current(), envVar, Root.setter);

		try {
			//processBuilder.command("sh", "ssh crkuma@lppbd0030 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.Hive");
			processBuilder.command("sh", "-c", "ssh crkuma@lppbd0030 java -cp /adshome/crkuma/GMS-Demo.jar demo.example.Hive");
			//processBuilder.command("ssh crkuma@lppbd0030 java -cp /adshome/crkuma/GMS-Example.jar demo.example.Hive");
			processBuilder.start();

		} catch (Exception e) {
			
		}
		} finally {
			span.end();
		}
		
		
		
		return "dataIngestion";
	};

	
	public static void process() {
		
		
		totalCount.get();
	
	}

	public static void main(String[] args) {
		
		process();

	}

}
