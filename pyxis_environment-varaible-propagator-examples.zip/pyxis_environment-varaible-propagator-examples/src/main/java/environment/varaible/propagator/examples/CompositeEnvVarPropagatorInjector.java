package environment.varaible.propagator.examples;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import com.amex.otel.environment.variable.trace.propagator.CompositeEnvironmentVariablePropagator;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.baggage.Baggage;
import io.opentelemetry.api.baggage.BaggageBuilder;
import io.opentelemetry.api.baggage.BaggageEntryMetadata;
import io.opentelemetry.api.baggage.propagation.W3CBaggagePropagator;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;
import io.opentelemetry.context.propagation.TextMapSetter;
import io.opentelemetry.extension.trace.propagation.B3Propagator;

public class CompositeEnvVarPropagatorInjector {

	private final Tracer tracer;
	private static final TextMapSetter<Map<String, String>> setter1 = Map::put;
	
	private static final String TRACEBAGGAGEVALUE = "cs.span.parent.id= 825553,cs.span.hash= a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad,"
			+ "cs.trace.id=a1308136f4fbc328358fa6237468ada5581,cs.trace.name=test_trace,cs.trace.time.start=1554843980180184094,"
			+ "cs.span.id=fa6237468ada558,cs.span.name=test_span_name,cs.span.time.start=1554843980180184094,"
			+ "cs.span.links=http://testlink/spanlink,cs.span.retry.id=1,cs.span.service.type=test,cs.span.service.name=spanservicename,"
			+ "cs.span.version= 1.0,cs.span.op.name= game_gccgm_game_card_cust_guid_map,cs.span.op.type=CREATETABLE,"
			+ "cs.trace.name=AUTO_DBT_TC_190,cs.trace.parent.id=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type=EE,cs.trace.version=1.0,"
			+ "cs.span.version1= 1.0,cs.span.op.name1= game_gccgm_game_card_cust_guid_map,cs.span.op.type1=CREATETABLE,"
			+ "cs.trace.name1=AUTO_DBT_TC_190,cs.trace.parent.id1=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type1=EE,cs.trace.version1=1.0,"
			+ "cs.span.version2= 1.0,cs.span.op.name2= game_gccgm_game_card_cust_guid_map,cs.span.op.type2=CREATETABLE,"
			+ "cs.trace.name2=AUTO_DBT_TC_190,cs.trace.parent.id2=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type2=EE,cs.trace.version2=1.0,"
			+ "cs.span.version3= 1.0,cs.span.op.name3= game_gccgm_game_card_cust_guid_map,cs.span.op.type3=CREATETABLE,"
			+ "cs.trace.name3=AUTO_DBT_TC_190,cs.trace.parent.id3=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type3=EE,cs.trace.version3=1.0,"
			+ "cs.span.version4= 1.0,cs.span.op.name4= game_gccgm_game_card_cust_guid_map,cs.span.op.type4=CREATETABLE,"
			+ "cs.trace.name4=AUTO_DBT_TC_190,cs.trace.parent.id4=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type4=EE,cs.trace.version4=1.0,"
			+ "cs.span.version5= 1.0,cs.span.op.name5= game_gccgm_game_card_cust_guid_map,cs.span.op.type5=CREATETABLE,"
			+ "cs.trace.name5=AUTO_DBT_TC_190,cs.trace.parent.id5=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type5=EE,cs.trace.version5=1.0,"
			+ "cs.span.version6= 1.0,cs.span.op.name6= game_gccgm_game_card_cust_guid_map,cs.span.op.type6=CREATETABLE,"
			+ "cs.trace.name6=AUTO_DBT_TC_190,cs.trace.parent.id6=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type6=EE,cs.trace.version6=1.0,"
			+ "cs.span.version7= 1.0,cs.span.op.name7= game_gccgm_game_card_cust_guid_map,cs.span.op.type7=CREATETABLE,"
			+ "cs.trace.name7=AUTO_DBT_TC_190,cs.trace.parent.id7=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type7=EE,cs.trace.version7=1.0,"
			+ "cs.span.version8= 1.0,cs.span.op.name8= game_gccgm_game_card_cust_guid_map,cs.span.op.type8=CREATETABLE,"
			+ "cs.trace.name8=AUTO_DBT_TC_190,cs.trace.parent.id8=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type8=EE,cs.trace.version6=1.0,"
			+ "cs.span.version9= 1.0,cs.span.op.name9= game_gccgm_game_card_cust_guid_map,cs.span.op.type9=CREATETABLE,"
			+ "cs.trace.name9=AUTO_DBT_TC_190,cs.trace.parent.id9=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type9=EE,cs.trace.version9=1.0,"
			+ "cs.span.version10= 1.0,cs.span.op.name10= game_gccgm_game_card_cust_guid_map,cs.span.op.type10=CREATETABLE,"
			+ "cs.trace.name10=AUTO_DBT_TC_190,cs.trace.parent.id10=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type10=EE,cs.trace.version10=1.0,"
			+ "cs.span.version11= 1.0,cs.span.op.name11= game_gccgm_game_card_cust_guid_map,cs.span.op.type11=CREATETABLE,"
			+ "cs.trace.name11=AUTO_DBT_TC_190,cs.trace.parent.id11=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type11=EE,cs.trace.version11=1.0,"
			+ "cs.span.version12= 1.0,cs.span.op.name12= game_gccgm_game_card_cust_guid_map,cs.span.op.type12=CREATETABLE,"
			+ "cs.trace.name12=AUTO_DBT_TC_190,cs.trace.parent.id12=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type12=EE,cs.trace.version12=1.0,"
			+ "cs.span.version13= 1.0,cs.span.op.name13= game_gccgm_game_card_cust_guid_map,cs.span.op.type13=CREATETABLE,"
			+ "cs.trace.name13=AUTO_DBT_TC_190,cs.trace.parent.id13=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type13=EE,cs.trace.version13=1.0,"
			+ "cs.span.version14= 1.0,cs.span.op.name14= game_gccgm_game_card_cust_guid_map,cs.span.op.type14=CREATETABLE,"
			+ "cs.trace.name14=AUTO_DBT_TC_190,cs.trace.parent.id14=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type14=EE,cs.trace.version14=1.0,"
			+ "cs.span.version15= 1.0,cs.span.op.name15= game_gccgm_game_card_cust_guid_map,cs.span.op.type15=CREATETABLE,"
			+ "cs.trace.name15=AUTO_DBT_TC_190,cs.trace.parent.id15=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type15=EE,cs.trace.version15=1.0,"
			+ "cs.span.version16= 1.0,cs.span.op.name16= game_gccgm_game_card_cust_guid_map,cs.span.op.type16=CREATETABLE,"
			+ "cs.trace.name16=AUTO_DBT_TC_190,cs.trace.parent.id16=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type16=EE,cs.trace.version16=1.0,"
			+ "cs.span.version17= 1.0,cs.span.op.name17= game_gccgm_game_card_cust_guid_map,cs.span.op.type17=CREATETABLE,"
			+ "cs.trace.name17=AUTO_DBT_TC_190,cs.trace.parent.id17=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type17=EE,cs.trace.version17=1.0,"
			+ "cs.span.version18= 1.0,cs.span.op.name18= game_gccgm_game_card_cust_guid_map,cs.span.op.type18=CREATETABLE,"
			+ "cs.trace.name18=AUTO_DBT_TC_190,cs.trace.parent.id18=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.trace.type18=EE,cs.trace.version18=1.0,"
			+ "cs.span.time.received=1610130185988,cs.span.links0=48790367,cs.span.name0=odl_example_child_1,cs.span.time.start=1610035023662,"
			+ "cs.span.type=EE,cs.trace.hash=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
			+ "cs.span.time.received1=1610130185988,cs.span.links1=48790367,cs.span.name1=odl_example_child_1,cs.span.time.start1=1610035023662,"
			+ "cs.span.type1=EE,cs.trace.hash1=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
			+ "cs.span.time.received2=1610130185988,cs.span.links2=48790367,cs.span.name2=odl_example_child_1,cs.span.time.start2=1610035023662,"
			+ "cs.span.type2=EE,cs.trace.hash2=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
			+ "cs.span.time.received3=1610130185988,cs.span.links3=48790367,cs.span.name3=odl_example_child_1,cs.span.time.start3=1610035023662,"
			+ "cs.span.type3=EE,cs.trace.hash3=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
			+ "cs.span.time.received4=1610130185988,cs.span.links4=48790367,cs.span.name4=odl_example_child_1,cs.span.time.start4=1610035023662,"
			+ "cs.span.type4=EE,cs.trace.hash4=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
			+ "cs.span.event.id=5e930a55-a793-4037-9fcf-5c3443eacc09,cs.span.event.state=dcbliwfuckwfcblwku,cs.service.name=odl_example_child_2,"
			+ "cs.service.type=dbchwjfbcwfchfhjhfhh,cs.trace.links=8366743864836,"
			+ "longvalue=a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad,"
			+ "longvalue1=a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdada1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad";


	public CompositeEnvVarPropagatorInjector(TracerProvider tracerProvider) {
		tracer = tracerProvider.get("environment.varaible.propagator.examples.CompositeEnvVarPropagatorInjector");
	}
	
	private void makeRequest() throws IOException {

		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}
		Span span = tracer.spanBuilder(hostname.concat("-").concat(ip.getHostAddress())).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "injector");
			span.setAttribute("propagator", "composite");

			span.setAttribute("host", hostname);

			span.end();
			ProcessBuilder processBuilder = new ProcessBuilder("CMD", "/C", "SET");
			// ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", "java -jar
			// /adshome/crkuma/JAVA2JAVAB3PropagatorExtractor.jar");
			//ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar","/adshome/crkuma/CompositeEnvVarPropagatorExtractor.jar");
			//ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar", "P:\\CompositePropagatorExtractor.jar");
			Map<String, String> env = processBuilder.environment();

			//String key = "cornestonetrace";
			/*String value = "cs.span.parent.id= 825553"
					+ ",cs.span.hash= a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad,cs.span.version= 1.0,"
					+ "cs.span.op.name= game_gccgm_game_card_cust_guid_map,cs.span.op.type=CREATETABLE,cs.span.time.received=1610130185988,"
					+ "cs.span.links=48790367,cs.span.name=odl_example_child_1,cs.span.time.start=1610035023662,cs.span.type=EE,"
					+ "cs.trace.hash=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
					+ "cs.trace.name=AUTO_DBT_TC_190,cs.trace.parent.id=5e930a55-a793-4037-9fcf-5c3443eacc09,"
					+ "cs.trace.type=EE,cs.trace.version=1.0,cs.trace.time.start=1610127663035,cs.span.event.name=game_gccgm_game_card,"
					+ "cs.span.event.type=CREATETABLE,cs.span.event.id=5e930a55-a793-4037-9fcf-5c3443eacc09,"
					+ "cs.span.event.state=dcbliwfuckwfcblwku,cs.service.name=odl_example_child_2,"
					+ "cs.service.type=dbchwjfbcwfchfhjhfhh,cs.trace.links=8366743864836,cs.trace.state=djncfkenvcflijnelijvlefijvdchbjwhfh";
			*/

		
			
			BaggageBuilder builder = Baggage.builder();
			CompositeEnvVarPropagatorInjector.extractEntries(TRACEBAGGAGEVALUE, builder);
			System.out.println("Baggage Size----->>>>"+builder.build().size());
			
			System.out.println(Context.current());

			CompositeEnvironmentVariablePropagator.getInstance(W3CTraceContextPropagator.getInstance(),
							W3CBaggagePropagator.getInstance(), B3Propagator.injectingSingleHeader()).inject(Context.current().with(builder.build()), env, setter1);
			

			try {
				System.out.println("Calling /adshome/crkuma/CompositeEnvVarPropagatorExtractor.jar");
				Process process = processBuilder.start();
				System.out.println("Done Calling /adshome/crkuma/CompositeEnvVarPropagatorExtractor.jar");
				InputStreamReader isr = new InputStreamReader(process.getInputStream());
				char[] buf = new char[1024];
				while (!isr.ready()) {
					;
				}
				while (isr.read(buf) != -1) {
					System.out.println(buf);
				}

				process.waitFor();
				System.out.println("Waiting ...");
				System.out.println("Returned Value :" + process.exitValue());

			} catch (Exception e) {
				e.printStackTrace();
			}

		} finally {
			span.end();
			System.out.println("Span ended in finally...");
		}
		
		

	}
	
	@SuppressWarnings("StringSplitter")
	  private static void extractEntries(String baggageHeader, BaggageBuilder baggageBuilder) {
	    // todo: optimize this implementation; it can probably done with a single pass through the
	    // string.
	    String[] entries = baggageHeader.split(",");
	    for (String entry : entries) {
	      String metadata = "";
	      int beginningOfMetadata = entry.indexOf(";");
	      if (beginningOfMetadata > 0) {
	        metadata = entry.substring(beginningOfMetadata + 1);
	        entry = entry.substring(0, beginningOfMetadata);
	      }
	      String[] keyAndValue = entry.split("=");
	      for (int i = 0; i < keyAndValue.length; i += 2) {
	        String key = keyAndValue[i].trim();
	        String value = keyAndValue[i + 1].trim();
	        baggageBuilder.put(key, value, BaggageEntryMetadata.create(metadata.trim()));
	      }
	    }
	  }

	public static void main(String[] args) {

		OpenTelemetry openTelemetry = ExampleConfiguration.initializeOpenTelemetry("10.16.126.64", 9411, "Injector");

		TracerProvider tracerProvider = openTelemetry.getTracerProvider();

		CompositeEnvVarPropagatorInjector example = new CompositeEnvVarPropagatorInjector(tracerProvider);
		try {
			example.makeRequest();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
