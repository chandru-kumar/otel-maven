package environment.varaible.propagator.examples;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import javax.annotation.Nullable;
import com.amex.otel.environment.variable.trace.propagator.CompositeEnvironmentVariablePropagator;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.baggage.Baggage;
import io.opentelemetry.api.baggage.BaggageEntry;
import io.opentelemetry.api.baggage.propagation.W3CBaggagePropagator;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;
import io.opentelemetry.context.propagation.TextMapSetter;
import io.opentelemetry.extension.trace.propagation.B3Propagator;

public class CompositeEnvVarPropagatorExtractor {

	private final Tracer tracer;
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};

	public CompositeEnvVarPropagatorExtractor(TracerProvider tracerProvider) {
		tracer = tracerProvider.get("environment.varaible.propagator.examples.CompositeEnvVarPropagatorExtractor");
	}

	public void makeRequest() throws IOException {
		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}
		
		Instant start = Instant.now();

		Map<String, String> env = System.getenv();

		Context context = CompositeEnvironmentVariablePropagator.getInstance(W3CTraceContextPropagator.getInstance(),
				W3CBaggagePropagator.getInstance(), B3Propagator.injectingSingleHeader()).extract(Context.current(), env, getter);

		Span span = tracer.spanBuilder(hostname.concat("-").concat(ip.getHostAddress())).setParent(context)
				.setSpanKind(SpanKind.CONSUMER).startSpan();

		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "injector");
			span.setAttribute("propagator", "composite");

			span.setAttribute("host", hostname);

			Map<String, BaggageEntry> baggageMap = Baggage.fromContext(context).asMap();

			for (Map.Entry<String, BaggageEntry> entry : baggageMap.entrySet()) {
				span.setAttribute(entry.getKey(),
						entry.getValue().getValue().concat(entry.getValue().getMetadata().getValue()));
			}

		} finally {
			span.end();
			Instant finish = Instant.now();
			long timeElapsed = Duration.between(start, finish).toMillis();
			System.out.println("Extracted trace details, created Spans and Baggages..in" + timeElapsed + " ms");
		}

	}

	public static void main(String[] args) {
		
		Instant start = Instant.now();
		OpenTelemetry openTelemetry = ExampleConfiguration.initializeOpenTelemetry("10.16.126.64", 9411, "Extractor");
		Instant finish = Instant.now();
		long timeElapsed = Duration.between(start, finish).toMillis();
		

		TracerProvider tracerProvider = openTelemetry.getTracerProvider();
		System.out.println("Extractor - Initialized OpenTelemetry, Exporter and Tracer..in" + timeElapsed + " ms");

		CompositeEnvVarPropagatorExtractor example = new CompositeEnvVarPropagatorExtractor(tracerProvider);
		try {
			example.makeRequest();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
