package environment.varaible.propagator.examples;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import javax.annotation.Nullable;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;
import io.opentelemetry.context.propagation.TextMapSetter;

public class EnvVarPropagatorW3CExtractor {

	private final Tracer tracer;
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};

	public EnvVarPropagatorW3CExtractor(TracerProvider tracerProvider) {
		tracer = tracerProvider.get("environment.varaible.propagator.examples.EnvVarPropagatorW3CExtractor");
	}
	
public void makeRequest() throws IOException {
		
		Map<String, String> env = System.getenv();
		
		Context context = EnvironmentVariablePropagator.getInstance(W3CTraceContextPropagator.getInstance()).extract(Context.current(), env, getter);

		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder(hostname.concat("-").concat(ip.getHostAddress())).setParent(context)
				.setSpanKind(SpanKind.CONSUMER).startSpan();
	
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "w3cextractor");
			span.setAttribute("propagator", "w3c");

			span.setAttribute("host", hostname);
			
		} finally {
			span.end();
		}

	}

	public static void main(String[] args) {

		OpenTelemetry openTelemetry = ExampleConfiguration.initializeOpenTelemetry("10.16.126.64", 9411, "W3CExtractor");

		TracerProvider tracerProvider = openTelemetry.getTracerProvider();

		EnvVarPropagatorW3CExtractor example = new EnvVarPropagatorW3CExtractor(tracerProvider);
		try {
			example.makeRequest();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
