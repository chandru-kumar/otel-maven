package environment.varaible.propagator.examples;

import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.concurrent.Callable;

import org.apache.logging.log4j.LogManager;

import com.amex.otel.environment.variable.trace.propagator.CompositeEnvironmentVariablePropagator;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.baggage.Baggage;
import io.opentelemetry.api.baggage.BaggageBuilder;
import io.opentelemetry.api.baggage.BaggageEntryMetadata;
import io.opentelemetry.api.baggage.propagation.W3CBaggagePropagator;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.api.trace.propagation.W3CTraceContextPropagator;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.extension.trace.propagation.B3Propagator;

public class TraceInjector implements Callable<Boolean> {
	
	private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(TraceInjector.class.getName());
	
	private static boolean createTraceandSpans(Tracer tracer) {

		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}
		Span span = tracer.spanBuilder(hostname.concat("-").concat(ip.getHostAddress())).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "injector");
			span.setAttribute("propagator", "composite");

			span.setAttribute("host", hostname);

			span.end();
			// ProcessBuilder processBuilder = new ProcessBuilder("CMD", "/C", "SET");
			// ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", "java -jar
			// /adshome/crkuma/JAVA2JAVAB3PropagatorExtractor.jar");
			// ProcessBuilder processBuilder = new ProcessBuilder("java",
			// "-jar","/adshome/crkuma/CompositeEnvVarPropagatorExtractor.jar");
			ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar", "P:\\CompositePropagatorExtractor.jar");
			Map<String, String> env = processBuilder.environment();

			// String key = "cornestonetrace";
			String value = "cs.span.parent.id= 825553"
					+ ",cs.span.hash= a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad,cs.span.version= 1.0,"
					+ "cs.span.op.name= game_gccgm_game_card_cust_guid_map,cs.span.op.type=CREATETABLE,cs.span.time.received=1610130185988,"
					+ "cs.span.links=48790367,cs.span.name=odl_example_child_1,cs.span.time.start=1610035023662,cs.span.type=EE,"
					+ "cs.trace.hash=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
					+ "cs.trace.name=AUTO_DBT_TC_190,cs.trace.parent.id=5e930a55-a793-4037-9fcf-5c3443eacc09,"
					+ "cs.trace.type=EE,cs.trace.version=1.0,cs.trace.time.start=1610127663035,cs.span.event.name=game_gccgm_game_card,"
					+ "cs.span.event.type=CREATETABLE,cs.span.event.id=5e930a55-a793-4037-9fcf-5c3443eacc09,"
					+ "cs.span.event.state=dcbliwfuckwfcblwku,cs.service.name=odl_example_child_2,"
					+ "cs.service.type=dbchwjfbcwfchfhjhfhh,cs.trace.links=8366743864836,cs.trace.state=djncfkenvcflijnelijvlefijvdchbjwhfh";

			// Baggage baggage = Baggage.builder().put(key,value.replace(" ",
			// "").replace("=", ":").replace(",", "|"))
			// Baggage baggage = Baggage.builder().put(key,value)
			// .put("meta", "meta-value",
			// BaggageEntryMetadata.create("somemetadata;someother=foo; somekey=somevalue"))
			// .build();

			/*
			 * BaggageBuilder builder = Baggage.builder(); builder.put("key", "value");
			 * builder.put("key1", "value1"); Baggage b = builder.build();
			 */

			BaggageBuilder builder = Baggage.builder();
			extractEntries(value, builder);

			System.out.println(Context.current());

			CompositeEnvironmentVariablePropagator.getInstance(W3CTraceContextPropagator.getInstance(),
					W3CBaggagePropagator.getInstance(), B3Propagator.injectingSingleHeader())
					.inject(Context.current().with(builder.build()), env, Map::put);

			try {
				log.info("Calling CompositeEnvVarPropagatorExtractor jar..");
				Process process = processBuilder.start();
				log.info("Done Calling CompositeEnvVarPropagatorExtractor jar..");
				InputStreamReader isr = new InputStreamReader(process.getInputStream());
				char[] buf = new char[1024];
				while (!isr.ready()) {
					;
				}
				while (isr.read(buf) != -1) {
					System.out.println(buf);
				}

				process.waitFor();
				System.out.println("Waiting ...");
				System.out.println("Returned Value :" + process.exitValue());

			} catch (Exception e) {
				e.printStackTrace();
			}

		} finally {
			span.end();
			System.out.println("Span ended in finally...");
		}

		return true;

	}

	@SuppressWarnings("StringSplitter")
	private static void extractEntries(String baggageHeader, BaggageBuilder baggageBuilder) {
		// todo: optimize this implementation; it can probably done with a single pass
		// through the
		// string.
		String[] entries = baggageHeader.split(",");
		for (String entry : entries) {
			String metadata = "";
			int beginningOfMetadata = entry.indexOf(";");
			if (beginningOfMetadata > 0) {
				metadata = entry.substring(beginningOfMetadata + 1);
				entry = entry.substring(0, beginningOfMetadata);
			}
			String[] keyAndValue = entry.split("=");
			for (int i = 0; i < keyAndValue.length; i += 2) {
				String key = keyAndValue[i].trim();
				String value = keyAndValue[i + 1].trim();
				baggageBuilder.put(key, value, BaggageEntryMetadata.create(metadata.trim()));
			}
		}
	}

	static OpenTelemetry initializeOpenTelemetryFeature() {
		log.info("Initializing OpenTelemetry..");
		return ExampleConfiguration.initializeOpenTelemetry("10.16.126.64", 9411, "Injector");
	}

	static Tracer getTracer(OpenTelemetry openTelemetry) {
		Tracer tracer;
		TracerProvider tracerProvider = openTelemetry.getTracerProvider();
		tracer = tracerProvider.get("environment.varaible.propagator.examples.CompositeEnvVarPropagatorInjector");
		log.info("Returning Tracer..");
		return tracer;
	}

	@Override
	public Boolean call() throws Exception {
		
		OpenTelemetry openTelemetry = initializeOpenTelemetryFeature();
		Tracer tracer = getTracer(openTelemetry);
		Boolean flag = createTraceandSpans(tracer);
		
		return true;
	}
	
	

}
