package environment.varaible.propagator.examples;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;
import io.opentelemetry.context.propagation.TextMapSetter;
import io.opentelemetry.extension.trace.propagation.B3Propagator;

public class EnvVarPropagatorB3Injector {

	private final Tracer tracer;
	private static final TextMapSetter<Map<String, String>> setter1 = Map::put;

	public EnvVarPropagatorB3Injector(TracerProvider tracerProvider) {
		tracer = tracerProvider.get("environment.varaible.propagator.examples.EnvVarPropagatorB3Injector");
	}
	
	private void makeRequest() throws IOException {

		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}
		Span span = tracer.spanBuilder(hostname.concat("-").concat(ip.getHostAddress())).setSpanKind(SpanKind.CLIENT)
				.startSpan();
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "b3injector");
			span.setAttribute("propagator", "b3");

			span.setAttribute("host", hostname);

			span.end();
			//ProcessBuilder processBuilder = new ProcessBuilder("CMD", "/C", "SET");
			// ProcessBuilder processBuilder = new ProcessBuilder("sh", "-c", "java -jar
			// /adshome/crkuma/JAVA2JAVAB3PropagatorExtractor.jar");
			//ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar","/adshome/crkuma/EnvVarPropagatorB3Injector.jar");
			ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar", "P:\\EnvVarPropagatorB3Extractor.jar");
			Map<String, String> env = processBuilder.environment();

			EnvironmentVariablePropagator.getInstance(B3Propagator.injectingSingleHeader()).inject(Context.current(), env, setter1);
			

			try {
				System.out.println("Calling /adshome/crkuma/EnvVarPropagatorB3Injector.jar");
				Process process = processBuilder.start();
				System.out.println("Done Calling /adshome/crkuma/EnvVarPropagatorB3Injector.jar");
				InputStreamReader isr = new InputStreamReader(process.getInputStream());
				char[] buf = new char[1024];
				while (!isr.ready()) {
					;
				}
				while (isr.read(buf) != -1) {
					System.out.println(buf);
				}

				process.waitFor();
				System.out.println("Waiting ...");
				System.out.println("Returned Value :" + process.exitValue());

			} catch (Exception e) {
				e.printStackTrace();
			}

		} finally {
			span.end();
			System.out.println("Span ended in finally...");
		}
		
		

	}

	public static void main(String[] args) {

		OpenTelemetry openTelemetry = ExampleConfiguration.initializeOpenTelemetry("10.16.126.64", 9411, "B3Injector");

		TracerProvider tracerProvider = openTelemetry.getTracerProvider();

		EnvVarPropagatorB3Injector example = new EnvVarPropagatorB3Injector(tracerProvider);
		try {
			example.makeRequest();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
