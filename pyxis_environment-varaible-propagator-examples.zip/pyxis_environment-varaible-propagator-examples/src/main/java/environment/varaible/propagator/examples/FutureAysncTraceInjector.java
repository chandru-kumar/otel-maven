package environment.varaible.propagator.examples;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;

public class FutureAysncTraceInjector {
	
	private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(FutureAysncTraceInjector.class.getName());


	public FutureAysncTraceInjector() {
	}

	private String doSomeOperation() {
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		log.info("doneSomeOperation");
		return "doneSomeOperation";
	}

	private String doSomeOtherOperation() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		log.info("doneSomeOtherOperation");
		return "doneSomeOperation";
	}

	public static void main(String[] args) {

		ExecutorService service = Executors.newSingleThreadExecutor();
		Future<Boolean> future = service.submit(new TraceInjector()); //future is a placeholder which holds the return value in few seconds
		
		FutureAysncTraceInjector example = new FutureAysncTraceInjector();
		
		example.doSomeOperation();
		example.doSomeOtherOperation();
		
		try {
			Boolean success = future.get(); //Blocking code - It waits untill the prcess done and retrun the future..
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
