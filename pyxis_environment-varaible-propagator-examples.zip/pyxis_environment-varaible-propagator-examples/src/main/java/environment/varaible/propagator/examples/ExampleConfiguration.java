/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

package environment.varaible.propagator.examples;

import java.time.Duration;
import java.time.Instant;

import org.apache.logging.log4j.LogManager;

import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.common.AttributeKey;
import io.opentelemetry.api.common.Attributes;
import io.opentelemetry.exporter.zipkin.ZipkinSpanExporter;
import io.opentelemetry.sdk.OpenTelemetrySdk;
import io.opentelemetry.sdk.resources.Resource;
import io.opentelemetry.sdk.trace.SdkTracerProvider;
import io.opentelemetry.sdk.trace.export.SimpleSpanProcessor;

/**
 * All SDK management takes place here, away from the instrumentation code, which should only access
 * the OpenTelemetry APIs.
 */
public class ExampleConfiguration {
  // Zipkin API Endpoints for uploading spans
  private static final String ENDPOINT_V2_SPANS = "/api/v2/spans";
  
  private static final org.apache.logging.log4j.Logger log = LogManager.getLogger(ExampleConfiguration.class.getName());

  // Name of the service
  //private static final String SERVICE_NAME = "Injector";

/*  static OpenTelemetry initializeOpenTelemetry1(String ip, int port, String SERVICE_NAME) {
    String httpUrl = String.format("http://%s:%s", ip, port);
    ZipkinSpanExporter zipkinExporter =
        ZipkinSpanExporter.builder()
            .setEndpoint(httpUrl + ENDPOINT_V2_SPANS)
            .setServiceName(SERVICE_NAME)
            .build();

    // Set to process the spans by the Zipkin Exporter
    OpenTelemetrySdk openTelemetry =
        OpenTelemetrySdk.builder()
            .setTracerProvider(
                SdkTracerProvider.builder()
                    .addSpanProcessor(SimpleSpanProcessor.create(zipkinExporter))
                    .build())
            .buildAndRegisterGlobal();

    // add a shutdown hook to shut down the SDK
    Runtime.getRuntime()
        .addShutdownHook(new Thread(() -> openTelemetry.getTracerManagement().shutdown()));

    // return the configured instance so it can be used for instrumentation.
    return openTelemetry;
  }*/
  
  static OpenTelemetry initializeOpenTelemetry(String ip, int port, String SERVICE_NAME) {
	  Instant start = Instant.now();
	    String httpUrl = String.format("http://%s:%s", ip, port);
	    ZipkinSpanExporter zipkinExporter =
	        ZipkinSpanExporter.builder().setEndpoint(httpUrl + ENDPOINT_V2_SPANS).build();

	    Resource serviceNameResource =
		        Resource.create(Attributes.of(AttributeKey.stringKey("SERVICE_NAME"), SERVICE_NAME));

	    // Set to process the spans by the Zipkin Exporter
	    SdkTracerProvider tracerProvider =
	        SdkTracerProvider.builder()
	            .addSpanProcessor(SimpleSpanProcessor.create(zipkinExporter))
	            .setResource(Resource.getDefault().merge(serviceNameResource))
	            .build();
	    OpenTelemetrySdk openTelemetry =
	        OpenTelemetrySdk.builder().setTracerProvider(tracerProvider).buildAndRegisterGlobal();

	    // add a shutdown hook to shut down the SDK
	    Runtime.getRuntime().addShutdownHook(new Thread(tracerProvider::shutdown));
	    
	    Instant finish = Instant.now();
	    long timeElapsed = Duration.between(start, finish).toMillis();
	    // return the configured instance so it can be used for instrumentation.
	    log.info("Initialized OpenTelemetry in " + timeElapsed + "ms");
	    System.out.println("Initialized OpenTelemetry in " + timeElapsed + "ms");
	    return openTelemetry;
	  }
}
