package environment.varaible.propagator.examples;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import javax.annotation.Nullable;
import com.amex.otel.environment.variable.trace.propagator.EnvironmentVariablePropagator;
import io.opentelemetry.api.OpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.api.trace.TracerProvider;
import io.opentelemetry.context.Context;
import io.opentelemetry.context.Scope;
import io.opentelemetry.context.propagation.TextMapGetter;
import io.opentelemetry.context.propagation.TextMapSetter;
import io.opentelemetry.extension.trace.propagation.B3Propagator;

public class EnvVarPropagatorB3Extractor {

	private final Tracer tracer;
	private static final TextMapGetter<Map<String, String>> getter = new TextMapGetter<Map<String, String>>() {
		@Override
		public Iterable<String> keys(Map<String, String> carrier) {
			return carrier.keySet();
		}

		@Nullable
		@Override
		public String get(Map<String, String> carrier, String key) {
			return carrier.get(key);
		}
	};

	public EnvVarPropagatorB3Extractor(TracerProvider tracerProvider) {
		tracer = tracerProvider.get("environment.varaible.propagator.examples.EnvVarPropagatorB3Extractor");
	}
	
public void makeRequest() throws IOException {
		
		Map<String, String> env = System.getenv();
		
		Context context = EnvironmentVariablePropagator.getInstance(B3Propagator.injectingSingleHeader()).extract(Context.current(), env, getter);

		InetAddress ip = null;
		String hostname = null;
		try {
			ip = InetAddress.getLocalHost();
			hostname = ip.getHostName();

		} catch (UnknownHostException e) {

			e.printStackTrace();
		}

		Span span = tracer.spanBuilder(hostname.concat("-").concat(ip.getHostAddress())).setParent(context)
				.setSpanKind(SpanKind.CONSUMER).startSpan();
	
		try (Scope scope = span.makeCurrent()) {
			span.setAttribute("component", "b3extractor");
			span.setAttribute("propagator", "b3");

			span.setAttribute("host", hostname);
			
		} finally {
			span.end();
		}

	}

	public static void main(String[] args) {

		OpenTelemetry openTelemetry = ExampleConfiguration.initializeOpenTelemetry("10.16.126.64", 9411, "B3Extractor");

		TracerProvider tracerProvider = openTelemetry.getTracerProvider();

		EnvVarPropagatorB3Extractor example = new EnvVarPropagatorB3Extractor(tracerProvider);
		try {
			example.makeRequest();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
