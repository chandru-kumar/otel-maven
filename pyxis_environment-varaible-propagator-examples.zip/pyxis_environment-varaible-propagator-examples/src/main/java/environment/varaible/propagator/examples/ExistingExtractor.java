package environment.varaible.propagator.examples;

import java.util.Map;

import io.opentelemetry.api.baggage.Baggage;
import io.opentelemetry.api.baggage.BaggageBuilder;
import io.opentelemetry.api.baggage.BaggageEntry;
import io.opentelemetry.api.baggage.BaggageEntryMetadata;
import io.opentelemetry.context.Context;

public class ExistingExtractor {
	
	private static int SINGLE_BAGGAGE_LIMIT = 1024;
	private static int BAGGAGE_LIMIT = 4096;
	private static int TRACE_LENGTH = 123;
	
	public static void main(String[] args) {
		ExistingExtractor obj = new ExistingExtractor();
		obj.extract(Context.current());
	}

	public <C> Context extract(Context context) {
		// String baggageHeader = getter.get(carrier, "Baggage");
		String baggageHeader = "cornestonetrace=cs.span.parent.id= 825553,"
		+ "cs.span.hash= a1308136f4fbc328358fa6237468ada5581ce47cea04799d7649481d1290fdad,cs.span.version= 1.0,"
		+ "cs.span.op.name= game_gccgm_game_card_cust_guid_map,cs.span.op.type=CREATETABLE,cs.span.time.received=1610130185988,"
		+ "cs.span.links=48790367,cs.span.name=odl_example_child_1,cs.span.time.start=1610035023662,cs.span.type=EE,"
		+ "cs.trace.hash=70ba04cadec3ec681b21f04c1bec21594f7cc31eee6e6c43e9ffbbb0419476a8,"
		+ "cs.trace.name=AUTO_DBT_TC_190,cs.trace.parent.id=5e930a55-a793-4037-9fcf-5c3443eacc09,"
		+ "cs.trace.type=EE,cs.trace.version=1.0,cs.trace.time.start=1610127663035,cs.span.event.name=game_gccgm_game_card,"
		+ "cs.span.event.type=CREATETABLE,cs.span.event.id=5e930a55-a793-4037-9fcf-5c3443eacc09,"
		+ "cs.span.event.state=dcbliwfuckwfcblwku,cs.service.name=odl_example_child_2,"
		+ "cs.service.type=dbchwjfbcwfchfhjhfhh,cs.trace.links=8366743864836,cs.trace.state=djncfkenvcflijnelijvlefijvdchbjwhfh";

		if (baggageHeader.isEmpty()) {
			return context.with(Baggage.empty());
		}

		BaggageBuilder baggageBuilder = Baggage.builder();
		//try {
			extractEntries(baggageHeader, baggageBuilder);
		/*} catch (Exception e) {
			System.out.println("Exception :"+e);
			return context.with(Baggage.empty());
		}*/
		return context.with(baggageBuilder.build());
	}

	@SuppressWarnings("StringSplitter")
	private static void extractEntries(String baggageHeader, BaggageBuilder baggageBuilder) {
		// todo: optimize this implementation; it can probably done with a single pass
		// through the
		// string.
		String[] entries = baggageHeader.split(",");
		for (String entry : entries) {
			System.out.println("Entry:"+entry);
			String metadata = "";
			int beginningOfMetadata = entry.indexOf(";");
			if (beginningOfMetadata > 0) {
				metadata = entry.substring(beginningOfMetadata + 1);
				entry = entry.substring(0, beginningOfMetadata);
			}
			String[] keyAndValue = entry.split("=");
			for (int i = 0; i < keyAndValue.length; i += 2) {
				String key = keyAndValue[i].trim();
				System.out.println(key);
				String value = keyAndValue[i + 1].trim();
				System.out.println(value);
				baggageBuilder.put(key, value, BaggageEntryMetadata.create(metadata.trim()));
			}
		}
	}
	

	public static <C> Context validate(Context context) {
		int baggageSize = 0;
		Baggage baggage = Baggage.fromContext(context);

		BaggageBuilder baggageBuilder = Baggage.builder();

		if (baggage.isEmpty() || baggage.size() == 0) {
			return context;
		}

		try {
			Map<String, BaggageEntry> baggageMap = Baggage.fromContext(context).asMap();
			for (Map.Entry<String, BaggageEntry> entry : baggageMap.entrySet()) {
				
				if (entry.getValue().getMetadata().getValue() != null
						&& !entry.getValue().getMetadata().getValue().isEmpty()) {
					baggageSize += (entry.getKey().length() + entry.getValue().getValue().length()
							+ entry.getValue().getMetadata().getValue().length());
					if ((!((entry.getKey().length() + entry.getValue().getValue().length()
							+ entry.getValue().getMetadata().getValue().length()) > SINGLE_BAGGAGE_LIMIT))
							&& (!((baggageSize + TRACE_LENGTH) > BAGGAGE_LIMIT))) {
						baggageBuilder.put(entry.getKey(), entry.getValue().getValue(),
								entry.getValue().getMetadata());
					}
				} else {
					baggageSize += (entry.getKey().length() + entry.getValue().getValue().length());
					if ((!((entry.getKey().length() + entry.getValue().getValue().length()) > SINGLE_BAGGAGE_LIMIT))
							&& (!((baggageSize + TRACE_LENGTH) > BAGGAGE_LIMIT))) {
						baggageBuilder.put(entry.getKey(), entry.getValue().getValue(),
								entry.getValue().getMetadata());
					}
				}

				if ((baggageSize + TRACE_LENGTH) > BAGGAGE_LIMIT) {
					break;
				}
			}
		} catch (Exception e) {
			return context.with(Baggage.empty());
		}

		if ((baggageSize + TRACE_LENGTH) > BAGGAGE_LIMIT) {
			return context.with(baggageBuilder.build());
		}

		return context;
	}
	
	
	//Returning empty baggage implementation code
	/*public static <C> Context validateBaggageSize(Context context) {
	int baggageSize = 0;
	Baggage baggage = Baggage.fromContext(context);
	StringBuilder sb = new StringBuilder();

	if (baggage.isEmpty() || baggage.size() == 0) {
		return context;
	}

	try {
		Map<String, BaggageEntry> baggageMap = Baggage.fromContext(context).asMap();
		for (Map.Entry<String, BaggageEntry> entry : baggageMap.entrySet()) {
			if (entry.getValue().getMetadata().getValue() != null
					&& !entry.getValue().getMetadata().getValue().isEmpty()) {
				baggageSize += (entry.getKey().length() + entry.getValue().getValue().length()
						+ entry.getValue().getMetadata().getValue().length());
				sb.append(entry.getKey()).append("=").append(entry.getValue().getValue())
						.append(entry.getValue().getMetadata().getValue()).append(";");
				if ((entry.getKey().length() + entry.getValue().getValue().length()
						+ entry.getValue().getMetadata().getValue().length()) > SINGLE_BAGGAGE_LIMIT) {
					logger.log(Level.INFO, "Baggage entry size exceeded 1 KB :" + sb.toString());
					return context.with(Baggage.empty());
				}
			} else {
				baggageSize += (entry.getKey().length() + entry.getValue().getValue().length());
				sb.append(entry.getKey()).append("=").append(entry.getValue().getValue()).append(";");
				if ((entry.getKey().length() + entry.getValue().getValue().length()) > SINGLE_BAGGAGE_LIMIT) {
					logger.log(Level.INFO, "Baggage entry size exceeded 1 KB :" + sb.toString());
					return context.with(Baggage.empty());
				}
			}
		}
	} catch (Exception e) {
		logger.log(Level.INFO, "Exception occurred while validating the baggage :" + sb.toString());
		return context.with(Baggage.empty());
	}

	if ((baggageSize + TRACE_LENGTH) > BAGGAGE_LIMIT) {
		logger.log(Level.INFO, "Baggage size exceeded 4 KB :" + sb.toString());
		return context.with(Baggage.empty());
	}

	return context;
}*/

}
