package com.amex.opentelemetry.annotations;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import io.opentelemetry.api.trace.Span;
import io.opentelemetry.context.Context;

public class InjectSpanTest {
	
	@Test
	void passValueToInjectSpanAnnotation() {
		test();
	}
	
	@InjectSpan(spanName = "test")
	private void test() {
		// TODO Auto-generated method stub
		System.out.println(Span.current().getSpanContext().getTraceId());
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>"+"00000000000000000000000000000000".equalsIgnoreCase(Span.fromContext(Context.current()).getSpanContext().getTraceId()));
		assertTrue("00000000000000000000000000000000".equalsIgnoreCase(Span.fromContext(Context.current()).getSpanContext().getTraceId()));
		
	}

}
