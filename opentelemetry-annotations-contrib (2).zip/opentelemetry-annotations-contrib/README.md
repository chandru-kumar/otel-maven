# OpenTelemetry Annotation

Provides annotations on method level to create spans and export the traces to see the Distributed tracing for End to End transaction.
Uses AspectJ features to create traces for the  methods applied with Annotations.

## InjectSpan Annotation

Creates new trace spans and makes the span as current span.

## InjectSpanToContext Annotation

Adds spans to current context and makes the span as current span.

## InjectChildSpanToContext Annotation

Adds spans as child span to current context.

### Build

Include aspectj-maven-plugin to build the project.

```
	<plugin>
				<groupId>org.codehaus.mojo</groupId>
				<artifactId>aspectj-maven-plugin</artifactId>
				<version>1.11</version>
				<configuration>
					<source>${maven.compiler.source}</source>
					<target>${maven.compiler.source}</target>
					<complianceLevel>${maven.compiler.source}</complianceLevel>
				</configuration>
				<executions>
					<execution>
						<goals>
							<goal>compile</goal>
						</goals>
					</execution>
				</executions>
				<dependencies>
					<dependency>
						<groupId>org.aspectj</groupId>
						<artifactId>aspectjtools</artifactId>
						<version>${aspectj.version}</version>
					</dependency>
				</dependencies>
			</plugin>
```